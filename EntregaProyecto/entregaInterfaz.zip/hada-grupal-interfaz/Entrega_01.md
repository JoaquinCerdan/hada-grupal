# IQÜEA - Comentarios

!!!Que tal equipo!!!

Vuestra propuesta de realizar una tienda on-line me parece genial y atractiva. Además, exponéis muchas funcionalidades con lo que lo convierte en un proyecto ambicioso y esto me encanta.

Respecto de los requisitos de la entrega, todo está correcto y cumple con lo pedido.

Respecto de las entidades, en un inicio parecen correctas.

Y nada más, gracias por vuestra propuesta y estoy deseando ver su evolución.

!!Un saludo!!
