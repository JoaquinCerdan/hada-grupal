# IQUEA - Comentarios Entrega 2

## Git
- La etiqueta ENCAD no ha sido creada.
- El deadline2 esta creado pero no esta cerrado.
- Cread y definid bien las issues, cuanto mejor sea el detalle, mejor ira todo durante el desarrollo.
- Cread y definid bien el .gitignore

## EN
- Las EN están implementadas pero no hacen las llamadas a los CAD.

## Esquema de la BBDD
- Correcto, buen trabajo!!!!

## Proyecto
- No he podido abrir correctamente el proyecto library. He visto que el archivo .sln está dentro de la carpeta del proyecto, siempre es mejor que el archivo .sln esté en la raiz de la solución.
- El error que me sale es: No se pudo cargar el archivo del proyecto. Un nombre no puede empezar con el carácter '<', valor hexadecimal 0x3C. línea 44, posición 2.  hada-grupal\iquea\iquea.csproj
- Es urgente que solucionéis esto ya que el proyecto lo tengo que poder descargar, abrir y ejecutar sin problemas.

## Requisitos EN
- Aseguraros de cumplir con los requisitos, cada miembro debe implementar dos EN o una en y sustituirlo por un servicio adicional. Recordad que en la entrega final, tendréis que indicar quién ha hecho cada cosa.

Saludos y buen trabajo, seguid así!!!