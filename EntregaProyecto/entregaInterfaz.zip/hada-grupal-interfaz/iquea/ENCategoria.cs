﻿using System;

/// <summary>
/// Summary description for ENCategoria
/// </summary>
public class ENCategoria
{

	private string nombre;

	private string descripcion;

	public ENCategoria()
	{

	}

	public ENCategoria(string nombre, string descripcion)
	{

	}

	public bool createCategoria()
	{
		return false;
	}

	public bool updateCategoria()
	{
		return false;
	}

	public bool readCategoria()
	{
		return false;
	}

	public bool deleteCategoria()
	{
		return false;
	}

}
