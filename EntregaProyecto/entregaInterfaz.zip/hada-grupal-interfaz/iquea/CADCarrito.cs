﻿using System;

public class CADCarrito
{
	private string constring;

    public bool createCarrito(ENCarrito carrito)
    {
        return false;
    }
    public bool readCarrito(ENCarrito carrito)
    {
        return false;
    }
    public bool updateCarrito(ENCarrito carrito)
    {
        return false;
    }

    public bool deleteCarrito(ENCarrito carrito)
    {
        return false;
    }


    public CADCarrito()
	{
	}
}
