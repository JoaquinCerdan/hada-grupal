﻿using System;

public class CADAnuncio
{
	public String constring;
	public CADAnuncio()
	{
		
	}
	

	public bool createAnuncio (ENAnuncio anun)
    {
		return false;
	}
	public bool readAnuncio (ENAnuncio anun)
    {
		return false;
	}
	public bool updateAnuncio (ENAnuncio anun)
    {
		return false;
	}

	public bool deleteAnuncio (ENAnuncio anun)
    {
		return false;
	}


}
