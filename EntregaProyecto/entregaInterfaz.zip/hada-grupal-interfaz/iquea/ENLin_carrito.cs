﻿using System;

public class ENLin_carrito
{
    private int id;
    private int numArticulos;

    public int idP { get { return this.id; } set { this.id = value; } }
    public int numArticulosP { get { return this.numArticulosP; } set { this.numArticulosP = value; } }

    public bool createLin_carrito()
    {
        return false;
    }
    public bool readLin_carrito()
    {
        return false;
    }
    public bool updateLin_carrito()
    {
        return false;
    }

    public bool deleteLin_carrito()
    {
        return false;
    }
    public ENLin_carrito()
    {
    }
    public ENLin_carrito(int numArticulos)
    {
    }
}
