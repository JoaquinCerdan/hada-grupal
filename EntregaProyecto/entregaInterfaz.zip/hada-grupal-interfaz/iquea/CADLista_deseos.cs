﻿using System;

public class CADLista_deseos
{
	private String constring;
	public CADLista_deseos()
	{
		
	}


	public bool createLista_deseos(ENLista_deseos list)
    {
		return false;
	}
	public bool readLista_deseos(ENLista_deseos list) 
	{
		return false;
	}
	public bool updateLista_deseos(ENLista_deseos list)
    {
		return false;
	}
	public bool deleteLista_deseos (ENLista_deseos list)
    {
		return false;
	}

}
