﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iquea
{
    class CADAdministrador
    {
        private string constring;

        public CADAdministrador()
        {
        }

        public bool createAdministrador(ENAdministrador ad)
        {
            return false;
        }

        public bool readAdministrador(ENAdministrador ad)
        {
            return false;
        }

        public bool deleteAdministrador(ENAdministrador ad)
        {
            return false;
        }

        public bool updateAdministrador(ENAdministrador ad)
        {
            return false;
        }
    }
}
