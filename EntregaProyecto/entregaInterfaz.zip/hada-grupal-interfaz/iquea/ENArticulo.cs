﻿using System;

/// <summary>
/// Summary description for ENArticulo
/// </summary>
public class ENArticulo
{
	
	private int id;

	private string descripcion;

	private double precio;

	private string imagen;

	private bool stock;

	public ENArticulo()
	{

	}

	public ENArticulo(int id, string descripcion, double precio, string imagen, bool stock)
	{

	}

	public bool createArticulo()
	{
		return false;
	}

	public bool updateArticulo()
	{
		return false;
	}

	public bool readArticulo()
	{
		return false;
	}

	public bool deleteArticulo()
	{
		return false;
	}

}
