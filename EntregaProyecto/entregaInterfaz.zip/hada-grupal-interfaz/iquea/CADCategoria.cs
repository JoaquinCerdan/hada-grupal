﻿using System;

/// <summary>
/// Summary description for CADCategoria
/// </summary>
public class CADCategoria
{
	public string constring;

	public CADCategoria()
    {

    }

	public bool createCategoria(ENCategoria cat)
	{
		return false;

	}

	public bool updateCategoria(ENCategoria cat)
	{
		return false;
	}

	public bool readCategoria(ENCategoria cat)
	{
		return false;
	}

	public bool deleteCategoria(ENCategoria cat)
	{
		return false;
	}

}
