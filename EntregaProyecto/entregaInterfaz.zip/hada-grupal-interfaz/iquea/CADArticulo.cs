﻿using System;

/// <summary>
/// Summary description for CADArticulo
/// </summary>
public class CADArticulo
{

	public string constring;

	public CADArticulo()
	{

	}

	public bool createArticulo(ENArticulo art)
	{
		return false;
	}

	public bool updateArticulo(ENArticulo art)
	{
		return false;
	}

	public bool readArticulo(ENArticulo art)
	{
		return false;
	}

	public bool deleteArticulo(ENArticulo art)
	{
		return false;
	}

}
