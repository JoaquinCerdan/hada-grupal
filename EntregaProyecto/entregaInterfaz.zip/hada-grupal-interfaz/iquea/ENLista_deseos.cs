﻿using System;

public class ENLista_deseos
{
	private int id;

	public int intId
    {
        get { return id; }
        set { id = value; }
    }

	public ENLista_deseos()
	{
	}

	public ENLista_deseos(int id)
    {

    }

    public bool createLista_deseos()
    {
        return false;
    }
    public bool readLista_deseos()
    {
        return false;
    }
    public bool updateLista_deseos()
    {
        return false;
    }
    public bool deleteLista_deseos()
    {
        return false;
    }
}
