﻿using System;

public class CADLin_carrito
{
    private string constring;

    public bool createLin_carrito(ENLin_carrito lin_carrito)
    {
        return false;
    }
    public bool readLin_carrito(ENLin_carrito lin_carrito)
    {
        return false;
    }
    public bool updateLin_carrito(ENLin_carrito lin_carrito)
    {
        return false;
    }

    public bool deleteLin_carrito(ENLin_carrito lin_carrito)
    {
        return false;
    }

    public CADLin_carrito()
	{
	}
}
