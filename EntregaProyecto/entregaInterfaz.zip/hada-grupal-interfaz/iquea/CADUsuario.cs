﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iquea
{
    class CADUsuario
    {
        private string constring;

        public CADUsuario()
        {
        }

        public bool createUsuario(ENUsuario ad)
        {
            return false;
        }

        public bool readUsuario(ENUsuario ad)
        {
            return false;
        }

        public bool deleteUsuario(ENUsuario ad)
        {
            return false;
        }

        public bool updateUsuario(ENUsuario ad)
        {
            return false;
        }
    }
}
